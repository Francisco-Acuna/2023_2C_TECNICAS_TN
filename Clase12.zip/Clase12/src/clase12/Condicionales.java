

package clase12;


public class Condicionales {
    public static void main(String[] args) {
        //condicionales
        
        System.out.println("**Estructura if**");
        
        /*
        
        if (){ entre paréntesis va la condición a evaluar
            sentencias que se ejecutan si la condición es
            verdadera
        } fin del if
        
        */
        int num1 = 50;
        int num2 = 100;
        
        if (num1 > num2){
            System.out.println("El número1 es mayor al número2");
        }
        System.out.println("Terminó la estructura if");
        
        if (num1 != 20) {
            System.out.println("El número1 es distinto a 20");
        }
        
        boolean log1 = true;
        
        if (log1) { //el booleano no se compara con == true
            System.out.println("Log1 es verdadero");
        }
        
        //podemos escribir el if en una línea
        //sólo cuando es una única sentencia
        if (num1 == 50) System.out.println("El num1 es 50");
        
        //si se ejecuta más de una instrucción, entonces
        //el cuerpo del if debe ir entre las llaves
        if (num1 > 20 && log1 ){
            System.out.println("El número1 es mayor a 20");
            System.out.println("Log1 es verdadero");
        }
        
        System.out.println("**Estructura if-else**");
        
        if (num1 > num2){
            System.out.println("El número1 es mayor al número2");
        } else {
            System.out.println("El número1 no es mayor al número2");
        }
        
        //también se puede escribir sin llaves, en línea
        //Siempre que se ejecute una sola sentencia por bloque
        if(num1 > num2) System.out.println("El primer número es mayor");
        else System.out.println("El primer número no es mayor");
        
        /*
        Ejercicio:
        dado un usuario="pepito"
        y una contraseña="1234"
        Diseñar un algoritmo que 
        si ingresa bien ambos datos informe: "Bienvenido pepito"
        de lo contrario, que informe: "ERROR - credenciales incorrectas"
        */
        
        String usuario = "pepito";
        String clave = "1234";
        
        if (usuario.equals("pepito") && clave.equals("1234")) {
            System.out.println("Bienvenido pepito");
        } else {
            System.out.println("ERROR - credenciales incorrectas");
        }
        
        
        
        
        
    }
}
