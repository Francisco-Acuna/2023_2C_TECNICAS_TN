/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase18;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Aula 8 - Docente
 */
public class Ejercicios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
	Crear un programa que simule la petici�n de
	una opci�n seg�n el siguiente men� y muestre
	en pantalla que ha ingresado a la opci�n
	seleccionada con las opciones siguientes:
	        
	�Gracias por contactarte con nosotros!
	�En qu� podemos ayudarte?
	A) Documentaci�n
	B) Cotizaci�n
	C) Asistencia
	D) Siniestros
	E) Informaci�n de Pagos
	F) Otras Consultas
	G) Anulaci�n
	Escribe la letra de la opci�n seleccionada.
	
	Debe mostrarse:
	Has elegido Documentaci�n (o la opci�n que haya elegido)
        */
        
        
        boolean inicializador = true;
        Scanner teclado = new Scanner(System.in);
         
        
//        System.out.println("�Gracias por contactarte con nosotros!\n" +
//"	�En qu� podemos ayudarte?\n" +
//"	A) Documentaci�n\n" +
//"	B) Cotizaci�n\n" +
//"	C) Asistencia\n" +
//"	D) Siniestros\n" +
//"	E) Informaci�n de Pagos\n" +
//"	F) Otras Consultas\n" +
//"	G) Anulaci�n\n" +
//"	Escribe la letra de la opci�n seleccionada.");  
//        String opcion = teclado.next().toUpperCase();
//        String mensaje = switch(opcion){
//            case "A" -> "Opci�n elegida -> Documentaci�n";
//            case "B" -> "Opci�n elegida -> Cotizaci�n";
//            case "C" -> "Opci�n elegida -> Asistencia";
//            case "D" -> "Opci�n elegida -> Siniestros";
//            case "E" -> "Opci�n elegida -> Informaci�n de Pagos";
//            case "F" -> "Opci�n elegida -> Otras Consultas";
//            case "G" -> "Opci�n elegida -> Anulaci�n";
//            default -> "La opci�n no existe";
//        };
//        
//        System.out.println(mensaje);
        
        
        /*
        Solicitar al usuario que ingrese dos n�meros.
        Luego ofrecerle un men� con las siguientes opciones:
        1-suma 2-resta 3-multiplicaci�n 4-divisi�n
        Finalmente, mostrar el resultado de la operaci�n
        aritm�tica elegida.
        */
        
//        System.out.println("Por favor ingresar dos n�meros para calcular:");
//        System.out.println("Ingrese el primero y presione enter:");
//        double num1 = teclado.nextDouble();
//        System.out.println("Ingrese el segundo y presione enter:");
//        double num2 = teclado.nextDouble();
//        
//        System.out.println("Elija la operaci�n deseada:\n 1-suma\n2-resta \n3-multiplicaci�n \n4-divisi�n");
//        int operacion = teclado.nextInt();
//        
//        switch(operacion){
//            case 1: System.out.println("Ha elegido la suma, el resultado es: "+(num1+num2)); break;
//            case 2: System.out.println("Ha elegido la resta, el resultado es: "+(num1-num2)); break;
//            case 3: System.out.println("Ha elegido la multiplicaci�n, el resultado es: "+(num1*num2)); break;
//            case 4: System.out.println("Ha elegido la divisi�n, el resultado es: "+(num1/num2)); break;
//            default: System.out.println("Opci�n no v�lida");
//        }

        
        /*
        Crear una aplicaci�n que valide el ingreso a una
        plataforma Online Banking a trav�s de una clave Token.
        
        Se debe tener en cuenta lo siguiente:
        * La Clave Token debe ser un n�mero aleatorio
        de 6 d�gitos.
        * El cliente debe ingresar los campos Usuario,
        Contrase�a y Clave Token (todos obligatorios).
        * El campo Usuario no distingue min�sculas
        o may�sculas.
        * El campo Contrase�a es sensible a las
        min�sculas y may�sculas.
        * La clave Token aleatoria se le informa al usuario al 
        pedirle que ingrese las credenciales.
        * El cliente solo posee 3 intentos de logueo. Si
        alcanza los 3 intentos fallidos de forma
        consecutiva, la aplicaci�n deber� informar al
        usuario que debe dirigirse a la sucursal del
        banco m�s cercana para poder desbloquear
        sus credenciales.
        * Por cada intento fallido, la aplicaci�n debe
        preguntar al cliente si desea continuar
        colocando las credenciales de manera
        correcta.
        * Si el cliente coloca las credenciales de forma
        correcta, deber� informar que ha ingresado
        correctamente al Online Banking.
        */
        
//        Random random = new Random();
//        //la clase Random se utiliza para generar n�meros aleatorios
//        System.out.println("** Bienvenido al portal de Online Banking **");
//        System.out.println("Por favor reg�strese.");
//        System.out.println("Ingrese su nombre de usuario:");
//        String usuario = teclado.nextLine();
//        System.out.println("Ingrese su clave personal:");
//        String clave = teclado.nextLine();
//        
//        int token = random.nextInt(1000000);
//        int intentos = 0;
//        
//        while(intentos < 3){
//            //al momento de pedirle las credenciales, le mostramos
//            //la clave token autogenerada
//            System.out.println("*** CLAVE TOKEN "+token+" ***");
//            
//            System.out.println("Para poder ingresar al sistema, complete sus credenciales:");
//            System.out.println("Ingrese su usuario:");
//            String usuarioIngresado = teclado.nextLine();
//            
//            System.out.println("Ingrese su contrase�a:");
//            String claveIngresada = teclado.nextLine();
//            
//            System.out.println("Ingrese el token");
//            int tokenIngresado = teclado.nextInt();
//            teclado.nextLine(); //capturamos el salto de l�nea
//            
//            //si las 3 credenciales son correctas, el usuario
//            //ingresa al Online Banking
//            if(usuarioIngresado.equalsIgnoreCase(usuario)
//                    && claveIngresada.equals(clave)
//                    && tokenIngresado == token){
//                System.out.println("Ingreso exitoso al Online Banking");
//                break;
//            }else {
//                //si las credenciales no son correctas (al menos una)
//                //se incrementa la cantidad de intentos fallidos
//                intentos++;
//                //si no alcanz� los 3 intentos, le mostramos los siguientes mensajes
//                if(intentos<3){
//                    System.out.println("Credenciales incorrectas.");
//                    System.out.println("Usted lleva "+intentos+" intentos fallidos");
//                    System.out.println("Recuerde que tiene s�lo 3 intentos, antes "
//                            + "de que se bloqueen sus credenciales");
//                }
//                
//                //le preguntamos al usuario si quiere volver a intentar
//                //cargar sus credenciales
//                if(intentos<3){
//                    String respuesta;
//                    //utilizamos una estructura do-while para asegurarnos 
//                    //de que responda correctamente
//                    do {
//                        System.out.println("Desea intentar nuevamente? SI/NO");
//                        respuesta = teclado.nextLine().toUpperCase();
//                        if(!respuesta.equals("SI") && !respuesta.equals("NO")){
//                            System.out.println("Debe ingresar \'SI\' o \'NO\'");
//                        }
//                    } while (!respuesta.equals("SI") && !respuesta.equals("NO"));
//                    
//                    //si la respuesta es "NO", lo saca del sistema
//                    if(respuesta.equals("NO")){
//                        System.out.println("Gracias por utilizar nuestro servicio.");
//                        break;
//                    }
//                }
//            }
//            
//            if(intentos==3){
//                System.out.println("Ha alcanzado el l�mite de intentos fallidos.");
//                System.out.println("*** CREDENCIALES BLOQUEADAS ***");
//                System.out.println("Por favor, dir�jase a la sucursal del banco"
//                        + " m�s cercana para desbloquear sus credenciales.");
//            }
//
//        }
        
        /*
        Una persona desea invertir $1000 en un banco, el
        cual le otorga un 2% de inter�s mensual �Cu�l
        ser� la cantidad de dinero que esta persona
        tendr� al cabo de un a�o?
        En el primer mes tendr� acumulado 1000 $ m�s
        20 $ de inter�s ( 2% de 1000 ). En el segundo
        mes se le sumar� un 2% a la base de 1020 $ del
        mes anterior y as� sucesivamente. 
        */
        
//        int inversion = 1000;
//        double inversionAcumulada = inversion;
//        double interes = 2;
//        double sumaTotal = 0;
//        
//        for(int i=1; i<=12; i++){
//            double gananciaMes = inversionAcumulada / 100 * interes;
//            sumaTotal += gananciaMes;
//            inversionAcumulada += gananciaMes;
//            System.out.println("Total mes "+i+": "+Math.round(inversionAcumulada));            
//        }
//        
//        System.out.println("Su capital inicial fue de $"+inversion);
//        System.out.println("Su capital final es de $"+Math.round(inversionAcumulada));
//        System.out.println("Tuvo una ganancia de: $"+Math.round(sumaTotal));
    
        
         /*
        Crear un programa que ingrese una oraci�n y
        muestre cu�l es el car�cter que m�s se repite.
        Consideraciones:
        * No se debe contabilizar el espacio en blanco.
        * La oraci�n a ingresar no debe estar vac�a.
        */
         
         String oracion;
         
         //realizo un do-while para asegurarme de que la oraci�n no est� vac�a
         do {
             System.out.println("Por favor, ingrese una oraci�n. La misma no debe estar vac�a.");
             oracion = teclado.nextLine();
             if(oracion.isBlank()){
                 System.out.println("TE DIJE QUE NO EST� VAC�AAAAA");
                 System.out.println("Por favor, ingrese nuevamente.");
             }
        } while (oracion.isBlank());
         
         //la damos un valor inicial con el primer caracter de la oraci�n
         //a la variable que va a contener el caracter m�s repetido
         char caracterMasRepetido = oracion.charAt(0);
         int cantidadDeRepeticiones = 0;
         
         for(int i=0; i<oracion.length(); i++){
             //almacenamos temporalmente el caracter actual del recorrido
             char caracter = oracion.charAt(i);
             
             
             
             
         }

        
        
    }
    
}
