

package curso.tecnicas.arreglos.ejercicios;

import java.util.Scanner;


public class ArreglosEjercicios {
    public static void main(String[] args) {
        
        /*
        Ejercicio 1:
        Crear un vector que contenga el monto de la facturaci�n total de
        una empresa durante un a�o (de enero a diciembre).
        Informar:
        - la m�xima facturaci�n
        - la facturaci�n m�s baja
        - el promedio de facturaci�n
        */
        
        double[] facturacionMensual = {12000, 15000, 10000, 45000, 20.35, 37.98, 32.12, 67000.65, 90.23, 120.24, 0, 120.24};
        double maximaFacturacion = facturacionMensual[0];
        double minimaFacturacion = facturacionMensual[0];
        double sumaTotal = 0;
        for(double f:facturacionMensual) {
            if(f>maximaFacturacion) maximaFacturacion=f;
            else if(f<minimaFacturacion) minimaFacturacion=f;
            sumaTotal += f;
        }
        
        
        double promFacturacion = sumaTotal / facturacionMensual.length;
        System.out.println("La m�xima facturaci�n es: "+maximaFacturacion);
        System.out.println("La m�nima facturaci�n es: "+minimaFacturacion);
        System.out.println("El promedio es: "+promFacturacion);
        
        /* 
        Ejercicio 2:
        Crear un vector de enteros de 10 posiciones
        Pedirle al usuario que cargue 10 valores para ese vector
        Mostrar con foreach el listado de n�meros que ingres�.
        Mostrar la suma de todos los elementos
        Mostrar el promedio
        Indicar cu�ntos n�meros pares y cu�ntos impares hay
        Indicar cu�ntas veces se repiti� el n�mero 2
        Resolver todo dentro de un m�todo que sea invocado dentro del main.
        */
        
        resolverEjercicio2();
        
    }
    
    public static void resolverEjercicio2(){
        int[] arreglo = crearVector();
        System.out.println("Los n�meros ingresados son:");
        for(int a:arreglo) System.out.print(a+" / ");
        System.out.println("");
    }
    
    public static int[] crearVector(){
        Scanner teclado = new Scanner(System.in);
        System.out.println("Indique qu� cantidad de elementos desea guardar:");
        int longitud = teclado.nextInt();
        int[] vector = new int[longitud];
        System.out.println("Ingrese los valores para el vector:");
        for(int i=0; i<vector.length;i++){
            System.out.print("Valor ("+i+") >> ");
            vector[i] = teclado.nextInt();
        }
        return vector;
    }
    

    
}
