

package clase22;

import java.util.Arrays;


public class Arreglos {
    public static void main(String[] args) {
        //si tuvi�ramos que guardar varios n�meros en variables:
        
        int variable1 = 456;
        int variable2 = 34;
        int variable3 = 98;
        
        /*
        Podemos generar un conjunto de variables y guardarlas dentro
        de un vector o arreglo bajo un mismo nombre que las agrupe a
        todas.
        Podemos acceder a cada valor de variable por medio del �ndice.
        Los �ndices comienzan en 0 y finalizan en la posici�n representada
        por la longitud -1.
        Optimizamos la lectura de la informaci�n al acceder por un mismo
        nombre a distintas variables y no por el nombre de cada una.
        */
        
        System.out.println("** Arreglos o Arrays **");
        
        /*
            declaraci�n:
            tipoDeDato[] identificador; --> declaraci�n
            tipoDeDato identificador[]; --> declaraci�n
            identificador = new tipoDeDato[n]; -> definici�n de longitud
            (la longitud es la cantidad de elementos que va a guardar)
        */
        
        float[] temperaturas; //declaraci�n
        temperaturas = new float[10]; //definimos la longitud en 10
        float temperaturas2[];
        temperaturas2 = new float[12];
        String[] nombres = new String[5];
        
       //asignaci�n de valores a las variables de un arreglo
       temperaturas[0] = 25.32f;
       temperaturas[1] = 12.56f;
//       temperaturas[2] = "Jose"; error porque no es el mismo tipo de dato

        nombres[3] = "Juan";
//        nombres[4] = 12.5f; error, no es el mismo tipo de dato
//        nombres[5] = "Lucas"; //error, excede el rango 
        
        
        //leer contenido de un �ndice
        System.out.println(temperaturas[0]);
        System.out.println(temperaturas[1]);
        System.out.println(nombres[3]);
        System.out.println(nombres[4]);

        //inicializaci�n
        int[] numeros = {12, 59, 87, 129, 0};
        //      �ndice    0   1   2   3   4
        //declaramos un vector de enteros de 5 posiciones
        
        //mostrar el contenido de un arreglo
        System.out.println(numeros); //no muestra el contenido
        //muestra la posici�n de memoria del vector.
        //Ya que el nombre es una referencia, no es el contenido
        
        System.out.println("Contenido del arreglo:");
        System.out.println(numeros[0]);
        System.out.println(numeros[1]);
        System.out.println(numeros[2]);
        System.out.println(numeros[3]);
        System.out.println(numeros[4]);
        
        System.out.println("\nContenido del arreglo por "
                + "contador o referencia");
        int contador = 0;
        System.out.println(numeros[contador]);
        contador++;
        System.out.println(numeros[contador]);
        contador++;
        System.out.println(numeros[contador]);
        contador++;
        System.out.println(numeros[contador]);
        contador++;
        System.out.println(numeros[contador]);
        
        System.out.println("Contenido del arreglo con for");
        for(int i=0; i<5; i++){
            System.out.println(numeros[i]);
        }
        
        for(int i=0; i<5; i++){
            System.out.println("El contenido del vector en la "
                    + "posici�n "+i+" es "+numeros[i]);
        }
        
        //longitud de un vector
        //el atributo length muestra la longitud del vector
        System.out.println("Longitud del vector");
        System.out.println(numeros.length);
        
        System.out.println("Recorrido con for con length");
        for(int i=0; i<numeros.length; i++){
            System.out.println(numeros[i]);
        }
        
        //copias de arreglos 
        char[] origen = {'a','b','c','x','@'};
        
        //creamos un arreglo de destino con la misma longitud
        char[] destino = new char[origen.length];
        
        System.out.println("Arreglo de origen:");
        for(int i=0; i<origen.length; i++){
            System.out.print(origen[i]+" ");
        }
        System.out.println("");
        
        System.out.println("Arreglo de destino:");
        for(int i=0; i<destino.length; i++){
            System.out.print(destino[i]+" ");
        }
        System.out.println("");
        
        //para copiar contenido:
//        System.out.println("Asignando valor por posici�n de a uno:");
//        destino[0] = origen[0];
//        destino[1] = origen[1];
//        destino[2] = origen[2];
//        destino[3] = origen[3];
//        destino[4] = origen[4];
//        
//        System.out.println("Arreglo de origen:");
//        for(int i=0; i<origen.length; i++){
//            System.out.print(origen[i]+" ");
//        }
//        System.out.println("");
//        
//        System.out.println("Arreglo de destino:");
//        for(int i=0; i<destino.length; i++){
//            System.out.print(destino[i]+" ");
//        }
//        System.out.println("");
        
//        System.out.println("Copiado de contenido con for");
//        for (int i=0; i<origen.length; i++) {
//            destino[i] = origen[i];
//        }
//        
//                System.out.println("Arreglo de origen:");
//        for(int i=0; i<origen.length; i++){
//            System.out.print(origen[i]+" ");
//        }
//        System.out.println("");
//        
//        System.out.println("Arreglo de destino:");
//        for(int i=0; i<destino.length; i++){
//            System.out.print(destino[i]+" ");
//        }
//        System.out.println("");
        
        System.out.println("Copiado con el m�todo arraycopy");
        int[] pares = {2 , 4, 6, 8, 10};
        int[] pares2 = new int[pares.length];
        
        System.out.println("recorrido de pares2");
        for (int i=0; i<pares2.length; i++) {
            System.out.println(pares2[i]);
        }
        
        System.arraycopy(pares, 0, pares2, 0, pares.length);
        //este m�todo recibe 5 par�metros
        //el primero es el vector de origen
        //el segundo es la posici�n desde donde se comienza a copiar
        //el tercero es el vector de destino
        //el cuarto es desde donde se comenzar� a copia en destino
        //el quinto es la cantidad de elementos que se van a copias
        
        System.out.println("recorrido de pares2");
        for (int i=0; i<pares2.length; i++) {
            System.out.println(pares2[i]);
        }
        
        //ordenar un vector
        int[] vector = {4, 56, 73, 12, 38, 1, 60, 7};
        System.out.println("Contenido del vector:");
        for(int i=0; i<vector.length; i++){
            System.out.println(vector[i]);
        }
        
        //el m�todo sort() ordena el vector
        Arrays.sort(vector);
        System.out.println("Contenido del vector (ordenado)");
        for(int i=0; i<vector.length; i++){
            System.out.println(vector[i]);
        }
        
        String[] palabras = {"hola", "java", "ala","zeta", "bota"};
        for(String p:palabras) System.out.println(p);
        Arrays.sort(palabras);
        System.out.println("********");
        for(String p:palabras) System.out.println(p);
    }
}
