/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase02;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int a; //declaración de variable con el tipo de dato
        a = 2; //asignación de valor a la variable
        a = 3; //cambio el valor de la variable
        int b = 3; //declaración y asignación en línea
        System.out.println(a);
        
        //una variable tiene una única declaración
        //e innumerables valores
        
        int c=12, d=23, e=41; //declaración y asignación múltiple en línea
        
        //Tipos de datos primitivos
        
        //byte - ocupa 1 byte y representa un entero
        //entre -128 y 127
        byte f = 100; 
        //byte g = -200; error no puede almacenar ese número
        System.out.println(f);
        
        //short - ocupa 2 bytes y representa un número entero
        //entre -32768 y 32767
        short g = 32500;
        System.out.println(g);
        
        //int - ocupa 4 bytes y representa un entero
        // entre -2147483648 y 2147483647
        int h = 325685;
        System.out.println(h);
        
        //long - ocupa 8 bytes y representa un entero
        //es un valor demasiado grande 
        long i = 46789123465L; //debo agregar una L al final de la literal
        System.out.println(i);
        
        //
        
        
    }
    
}
