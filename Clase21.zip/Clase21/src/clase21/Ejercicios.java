

package clase21;

import java.util.Scanner;


public class Ejercicios {
    public static void main(String[] args) {
        /*
        Crear un programa que tenga un m�todo al cual se le 
        ingrese una frase como par�metro y luego imprima por 
        consola la misma frase repetida 7 veces.
        */
        
        String fraseNueva = "cualquier cosa";
        repetirFraseSieteVeces(fraseNueva);
        
        /*
        Crear un programa que reciba 3 par�metros y calcule la
        suma, resta, multiplicaci�n, divisi�n y el resto de dos 
        n�meros con decimales.
        Las consignas para lograrlo son:
        * Crear un m�todo que no retorne nada, que reciba los 3
        par�metros (2 n�meros con decimales y el caracter de la
        operaci�n)
        * Crear los m�todos de las operaciones que retornen el 
        resultado con decimales
        * Mostrar por consola un mensaje que indique el resultado
        y la operaci�n realizada.
        */
        
        Scanner teclado = new Scanner(System.in);
        System.out.println("Por favor ingrese un n�mero y presione enter:");
        double numero1 = teclado.nextDouble();
        System.out.println("Por favor ingrese un n�mero y presione enter:");
        double numero2 = teclado.nextDouble();
        teclado.nextLine();
        System.out.println("Inserte el caracter de la operaci�n que quiere realizar:");
        String operador = teclado.nextLine();
        
        calcularOperaciones(numero1, numero2, operador);
        
        
    } // final del m�todo main
    
    
    public static void repetirFraseSieteVeces(String frase){
        for (int i = 1; i <= 7; i++) {
            System.out.println(frase);
        }
    }
    
    public static void calcularOperaciones(double num1, double num2, String operador){
        switch(operador){
            case "+": System.out.println(sumar(num1, num2)); break;
            case "-": System.out.println(restar(num1, num2)); break;
            case "*": System.out.println(multiplicar(num1, num2)); break;
            case "/": 
                if(num2==0){
                    System.out.println("No se puede dividir por 0.");
                    break;
                }else{
                    System.out.println(dividir(num1, num2));
                    break;
                }
            case "%": 
                if(num2==0){
                    System.out.println("No se puede obtener el resto de una divisi�n por 0.");
                    break;
                }else{
                    System.out.println(obtenerResto(num1, num2));
                    break;
                }
            default: System.out.println("El caracter ingresado no es v�lido!");
        }
    }
    
    public static double sumar(double num1, double num2){
        System.out.print("La operaci�n elegida fue una suma y el resultado es: ");
        return num1 + num2;
    }
    
    public static double restar(double num1, double num2){
        System.out.print("La operaci�n elegida fue una resta y el resultado es: ");
        return num1 - num2;
    }
    
    public static double multiplicar(double num1, double num2){
        System.out.print("La operaci�n elegida fue una multiplicaci�n y el resultado es: ");
        return num1 * num2;
    }
    
    public static double dividir(double num1, double num2){
        System.out.print("La operaci�n elegida fue una divisi�n y el resultado es: ");
        return num1 / num2;
    }
    
    public static double obtenerResto(double num1, double num2){
        System.out.print("La operaci�n elegida fue el resto y el resultado es: ");
        return num1 % num2;
    }
    
    
} //final de la clase
