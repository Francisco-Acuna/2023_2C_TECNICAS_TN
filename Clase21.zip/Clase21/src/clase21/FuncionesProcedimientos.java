

package clase21;

import java.util.Scanner;


public class FuncionesProcedimientos {
    public static void main(String[] args) {
        
        
        System.out.println("\n############################\n");
        
        System.out.println("Funciones y procedimientos");
        
        /*
        Las funciones y procedimientos son un bloque de c�digo
        que contienen una o m�s intrucciones, al cual podemos
        invocar para que sean ejecutadas. 
        Las funciones y los procedimientos nos van a ayudar a hacer
        nuestro c�digo m�s legible y evitar c�digo duplicado.
        */
        
        /*
        Los m�todos de tipo funci�n, siempre retornan un valor.
        En su declaraci�n deben indicar qu� tipo de valor retornan.
        En su cuerpo, deben contener la sentencia 'return', con el 
        retorno del tipo de dato que se indic� en su cabecera.
        */
        
        System.out.println("Funciones");
        //invoco al m�todo para darle valor a la variable
        int numero1 = retornarNumeroDiez(); //llamar o invocar al m�todo
        System.out.println(numero1);
        System.out.println(retornarNumeroDiez());  
        
        int numero3 = 17;
        System.out.println(sumarDosEnteros(numero1, numero3));
        System.out.println(sumarDosEnteros(32, 25));
        
        System.out.println(esPar(numero1));
        
                
        System.out.println("** Procedimientos **");
        /*
        Los m�todos de tipo procedimiento no tienen un retorno.
        En su declaraci�n deben llevar la palabra reservada 'void'
        para indicar que no tienen retorno.
        */
        
        saludar(); //esta es la llamada o invocaci�n del m�todo
        String usuario = "Saucedo";
        Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese su nombre de usuario");
        usuario = teclado.nextLine();
        saludarNombre(usuario);
        
        float base = 12.5f;
        float altura = 25.2f;
        calcularAreaRectangulo(base, altura);
        calcularAreaRectangulo(12.5f, 25.2f);
        
        sumarParImpar(4, 15, "Saucedo");
        
    } //final del m�todo main
    
    //creamos una funci�n
    public static int retornarNumeroDiez(){
        return 10;
    }

    public static int sumarDosEnteros(int nro1, int nro2){
        //esta funci�n recibe 2 par�metros
        //los par�metros son valores de entrada
        //se declaran indicando primero el tipo de dato y luego el identificador
        //el nombre o identificador es a modo de referencia, ya que cuando 
        //invoquemos al m�todo, no hace falta que se llamen igual
        return nro1 + nro2;
    }
    
    public static boolean esPar(int numero){
//        if(numero%2 == 0){
//            return true;
//        }else{
//            return false;
//        }
        return numero%2 == 0;
    }
    
    
    //Ejemplos de procedimientos
    public static void saludar(){
        System.out.println("Hola Mundo!!");
    }
    
    
    public static void saludarNombre(String nombre){
        System.out.println("Hola "+nombre+"!!");
    }
    
    /**
     * Este m�todo informa el �rea de un rect�ngulo
     * @param base es la base del rect�ngulo que quiero calcular
     * @param altura es la altura del rect�ngulo que quiero calcular
     */
    public static void calcularAreaRectangulo(float base, float altura){
        float area = base * altura;
        System.out.println("El area es igual a "+area);
    }
    
    //m�todos dentro de m�todos
    public static void sumarParImpar(int num1, int num2, String nombre){
        saludarNombre(nombre);
        if(esPar(sumarDosEnteros(num1, num2))){
            System.out.println("La suma es par!!");
        }else{
            System.out.println("La suma es impar :-(");
        }
    }
    
    
} //final de la clase
