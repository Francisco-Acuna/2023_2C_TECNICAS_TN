

package clase21;


public class Arreglos {
    public static void main(String[] args) {
        //si tuvi�ramos que guardar varios n�meros en variables:
        
        int variable1 = 456;
        int variable2 = 34;
        int variable3 = 98;
        
        /*
        Podemos generar un conjunto de variables y guardarlas dentro
        de un vector o arreglo bajo un mismo nombre que las agrupe a
        todas.
        Podemos acceder a cada valor de variable por medio del �ndice.
        Los �ndices comienzan en 0 y finalizan en la posici�n representada
        por la longitud -1.
        Optimizamos la lectura de la informaci�n al acceder por un mismo
        nombre a distintas variables y no por el nombre de cada una.
        */
        
        System.out.println("** Arreglos o Arrays **");
        
        /*
            declaraci�n:
            tipoDeDato[] identificador; --> declaraci�n
            tipoDeDato identificador[]; --> declaraci�n
            identificador = new tipoDeDato[n]; -> definici�n de longitud
            (la longitud es la cantidad de elementos que va a guardar)
        */
        
        float[] temperaturas; //declaraci�n
        temperaturas = new float[10]; //definimos la longitud en 10
        float temperaturas2[];
        temperaturas2 = new float[12];
        String[] nombres = new String[5];
        
       //asignaci�n de valores a las variables de un arreglo
       temperaturas[0] = 25.32f;
       temperaturas[1] = 12.56f;
//       temperaturas[2] = "Jose"; error porque no es el mismo tipo de dato

        nombres[3] = "Juan";
//        nombres[5] = "Lucas"; error, excede el rango 
        
        
    }
}
