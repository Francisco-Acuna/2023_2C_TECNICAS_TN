/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase09;

import java.util.Scanner;


/**
 *
 * @author Aula 8 - Docente
 */
public class Clase09 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("** Clase System **");
        /*
        La clase System es un intermediario entre la JVM
        y el entorno de ejecución en el que estamos ejecutando
        nuestro programa.
        Como la máquina virtual de Java puede ejecutarse en 
        múltiples plataformas, la clase System nos abstrae de la
        plataforma sobre la que se está ejecutando
        */
        
        /*
        Los atributos más clásicos son out, err, in
        Representan stream de entrada y salida
        son atributos finales y estáticos
        out es un stream de salida sincronizado
        err es un stream de salida desincronizado
        in es un stream de entrada sincronizado
        */
        
        /*
        "stream" (flujo o corriente), es una secuencia de datos
        que se procesa o transmite de manera secuencial, en lugar
        de cargarse o procesarse en su totalidad antes de usarse
        */
        
        //out es sincronizado
        System.out.println("Hola 1");
        System.out.println("Hola 2");
        System.out.println("Hola 3");
        System.out.println("Hola 4");
        System.out.println("Hola 5");
        System.out.println("Hola 6");
        System.out.println("Hola 7");
        System.out.println("Hola 8");
        System.out.println("Hola 9");
        System.out.println("Hola 10");
        System.out.println("Hola 11");
        System.out.println("Hola 12");
        System.out.println("Hola 13");
        System.out.println("Hola 14");
        System.out.println("Hola 15");
        System.out.println("Hola 16");
        System.out.println("Hola 17");
        System.out.println("Hola 18");
        System.out.println("Hola 19");
        System.out.println("Hola 20");
        
        //err es desincronizado
        System.err.println("Ocurrió un error!");
        
        //.exit()
        //cierra el runtime, es decir, que finaliza el programa
//        System.out.println("Ejecuto el método exit()");
//        System.exit(0);
//        System.out.println("Esta sentencia no se ejecuta.");
        //el parámetro 0 indica que no hubo error al terminar el programa
        //el parámetro 1 indica que hubo error al terminar el programa
        
        /*
        diccionario getenv()
        este método devuelve un diccionario de propiedades del 
        entorno de ejecución, es decir, propiedades del sistema,
        que varían según SO y versión de Java
        */
        System.out.println("\ngetenv()");
        System.out.println(System.getenv());
        
        //getProperties() representa un mapa o vector asociativo
        //que es igual en todas las configuraciones.
        System.out.println(System.getProperties()); //propiedades del sistema
        System.out.println(System.getProperty("os.name")); //nombre del SO
        System.out.println(System.getProperty("os.version")); //versión del SO
        System.out.println(System.getProperty("os.arch")); //arquitectura (32 o 64 bits)
        System.out.println(System.getProperty("java.version")); //versión de Java
        System.out.println(System.getProperty("user.name")); //nombre de usuario del SO
        System.out.println(System.getProperty("user.home")); //directorio del usuario
        
        //el atributo in representa un stream de entrada y es
        //sincronizado, permite ingresar datos desde la terminal
        //del sistema, por ejemplo con la clase Scanner
        
        System.out.println("\n** Clase Scanner **");
        //declaro un objeto de la clase Scanner
        Scanner teclado = new Scanner(System.in);
        
//        System.out.println("Ingrese su nombre:");
//        String nombre = teclado.next();
        //el método next() captura hasta el primer espacio
        //next() detiene el hilo de ejecución, el programa
        //se queda esperando que el usuario ingrese el dato
        //y presione enter
//        System.out.println("Hola, tu nombre es: "+nombre);
        
        System.out.println("Ingrese sus nombres:");
        String nombres = teclado.nextLine();
        System.out.println("Sus nombres son: "+nombres);
        
        System.out.println("Ingrese su edad:");
        int edad = teclado.nextInt();
        System.out.println("Su edad es de "+edad+" años.");
        
        /*
        solicitar al usuario que ingrese 3 números enteros
        Luego informar:
        1) la suma de los dos primeros
        2) la resta de los dos segundos
        3) el resto entre el primero y el segundo
        4) la suma total
        5) el promedio
        */
    }
    
}
