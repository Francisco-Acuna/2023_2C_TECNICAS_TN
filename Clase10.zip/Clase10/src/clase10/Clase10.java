/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase10;

import java.util.Scanner;



/**
 *
 * @author Aula 8 - Docente
 */
public class Clase10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
        solicitar al usuario que ingrese 3 números enteros
        Luego informar:
        1) la suma de los dos primeros
        2) la resta de los dos segundos
        3) el resto entre el primero y el segundo
        4) la suma total
        5) el promedio
        */
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Por favor, ingrese 3 números enteros: ");
        System.out.println("A continuación ingrese el primero y presione enter:");
        int primero = teclado.nextInt();
        System.out.println("A continuación ingrese el segundo y presione enter:");
        int segundo = teclado.nextInt();
        System.out.println("A continuación ingrese el tercero y presione enter:");
        int tercero = teclado.nextInt();
        
        int sumaDosNumeros = primero + segundo;
        int restaDosNumeros = segundo - tercero;
        int resto = primero % segundo;
        int sumaTotal = primero + segundo + tercero;
        int promedio = sumaTotal / 3;
        
        System.out.println("La suma de los dos primeros es: "+sumaDosNumeros);
        System.out.println("La resta de los dos segundos es: "+restaDosNumeros);
        System.out.println("El resto entre el primero y el segundo es: "+resto);
        System.out.println("La suma total de los 3 números es: "+sumaTotal);
        System.out.println("El promedio es de: "+promedio);
        
        
        
        
        
        
    }   
    
}
