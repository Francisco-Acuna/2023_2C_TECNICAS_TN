

package clase20;


public class Ejercicios {
    public static void main(String[] args) {
        /*
        Crear un programa que tenga un m�todo al cual se le 
        ingrese una frase como par�metro y luego imprima por 
        consola la misma frase repetida 7 veces.
        */
        
        String fraseNueva = "cualquier cosa";
        repetirFraseSieteVeces(fraseNueva);
        
        /*
        Crear un programa que reciba 3 par�metros y calcule la
        suma, resta, multiplicaci�n, divisi�n y el resto de dos 
        n�meros con decimales.
        Las consignas para lograrlo son:
        * Crear un m�todo que no retorne nada, que reciba los 3
        par�metros (2 n�meros con decimales y el caracter de la
        operaci�n)
        * Crear los m�todos de las operaciones que retornen el 
        resultado con decimales
        * Mostrar por consola un mensaje que indique el resultado
        y la operaci�n realizada.
        */
    }
    
    public static void repetirFraseSieteVeces(String frase){
        for (int i = 1; i <= 7; i++) {
            System.out.println(frase);
        }
    }
    
}
