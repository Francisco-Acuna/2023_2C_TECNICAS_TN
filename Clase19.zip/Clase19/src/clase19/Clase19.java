

package clase19;

import java.util.Scanner;


public class Clase19 {
    public static void main(String[] args) {
        System.out.println("*** Estructura for ***");
        //la estructura for es una estructura repetitiva
        
        //imprimir los n�meros del 1 al 10 uno debajo del otro
        for(int i=1; i<=10; i++){
            System.out.println(i);
        }
        
        //con while
        System.out.println("\nCon while\n");
        int contador = 1;
        while(contador<=10){
            System.out.println(contador);
            contador++;
        }
        
        
        //cuando se ejecuta una �nica sentencia del for
        //se puede escribir en l�nea
        for(int i=1; i<=5; i++) System.out.println("Hola Mundo!!");
        
        /*
        La variable que est� dentro del for es una variable local.
        S�lo se utiliza dentro del for, no tiene alcance (scope)
        fuera de la estructura. Al terminar el bucle for, desaparece,
        es decir, deja de ocupar un lugar en memoria.
        */
        
        //imprimir los n�meros del 1 al 10 uno debajo del otro
        //sin imprimir los n�meros 2, 5 y 9
        System.out.println("-------------------");
        for(int i=1; i<=10; i++){
            if(i!=2 && i!=5 && i!=9) System.out.println(i);
        }
        
        //imprimir los n�meros del 1 al 30
        //sin imprimir los n�meros entre el 10 y el 20
        System.out.println("-------------------");
        for(int i=1; i<=30; i++){
            if(i<10 || i>20) System.out.println(i);
        }
        
        //imprimir los n�meros del 1 al 20
        //salteando de 2 en 2, uno al lado del otro
        System.out.println("-------------------");
        for(int i=1; i<=20; i+=2){
            System.out.print(i+" ");
        }
        
        System.out.println("");
        
        //imprimir los n�meros del 10 al 1
        //uno debajo del otro
        System.out.println("-------------------");
        for(int i=10; i>0; i--){
            System.out.println(i);
        }
        
        System.out.println("\n############################\n");
        
        System.out.println("Funciones y procedimientos");
        
        /*
        Las funciones y procedimientos son un bloque de c�digo
        que contienen una o m�s intrucciones, al cual podemos
        invocar para que sean ejecutadas. 
        Las funciones y los procedimientos nos van a ayudar a hacer
        nuestro c�digo m�s legible y evitar c�digo duplicado.
        */
        
        /*
        Los m�todos de tipo funci�n, siempre retornan un valor.
        En su declaraci�n deben indicar qu� tipo de valor retornan.
        En su cuerpo, deben contener la sentencia 'return', con el 
        retorno del tipo de dato que se indic� en su cabecera.
        */
        
        System.out.println("Funciones");
        //invoco al m�todo para darle valor a la variable
        int numero1 = retornarNumeroDiez();
        System.out.println(numero1);
        System.out.println(retornarNumeroDiez());        
                
        int numero3 = 17;
        System.out.println(sumarDosEnteros(numero1, numero3));
        
        System.out.println(esPar(numero1));
        
                
        System.out.println("** Procedimientos **");
        /*
        Los m�todos de tipo procedimiento no tienen un retorno.
        En su declaraci�n deben llevar la palabra reservada 'void'
        para indicar que no tienen retorno.
        */
        
        saludar(); //esta es la llamada o invocaci�n del m�todo
        String usuario = "Saucedo";
        Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese su nombre de usuario");
        usuario = teclado.nextLine();
        saludarNombre(usuario);
        
        
        
    } //final del m�todo main
    
    //creamos una funci�n
    public static int retornarNumeroDiez(){
        return 10;
    }
    
    public static int sumarDosEnteros(int nro1, int nro2){
        //esta funci�n recibe 2 par�metros
        //los par�metros son valores de entrada
        //se declaran indicando primero el tipo de dato y luego el identificador
        //el nombre o identificador es a modo de referencia, ya que cuando 
        //invoquemos al m�todo, no hace falta que se llamen igual
        return nro1 + nro2;
    }
    
    public static boolean esPar(int numero){
//        if(numero%2 == 0){
//            return true;
//        }else{
//            return false;
//        }
        return numero%2 == 0;
    }
    
    
    //Ejemplos de procedimientos
    public static void saludar(){
        System.out.println("Hola Mundo!!");
    }
    
    public static void saludarNombre(String nombre){
        System.out.println("Hola "+nombre+"!!");
    }
    
    /**
     * Este m�todo informa el �rea de un rect�ngulo
     * @param base es la base del rect�ngulo que quiero calcular
     * @param altura es la altura del rect�ngulo que quiero calcular
     */
    public static void calcularAreaRectangulo(float base, float altura){
        float area = base * altura;
        System.out.println("El area es igual a "+area);
    }
    
    
    
} //final de la clase
